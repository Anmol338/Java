package mylibs;

public class Global {
	public static final String ROOM_TYPES[] = {"Single","Double","Deluxe"};
	public static final double ROOM_RATE[] = {1000,1500,2000};
	public static final String ROOM_STATUS[] = {"Available","Booked"};
}
