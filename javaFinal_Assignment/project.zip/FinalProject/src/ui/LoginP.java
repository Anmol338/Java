package ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Essential.Dash;

public class LoginP implements ActionListener {

	JPanel panel, panel1, panel2;
	JLabel label, label1, label2;
	JTextField txt;
	JPasswordField pass;
	JButton btn , btn1;

	public LoginP() {
		JFrame frame = new JFrame("LOTON");
		frame.setSize(700, 510);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setLayout(new BorderLayout());

		panel = new JPanel();
		panel.setBackground(Color.pink);
		panel.setPreferredSize(new Dimension(150, 100));
		frame.add(panel, BorderLayout.NORTH);

		panel1 = new JPanel();
		panel1.setBackground(Color.pink);
		panel1.setPreferredSize(new Dimension(200, 120));
		frame.add(panel1, BorderLayout.SOUTH);

		panel2 = new JPanel();
		panel2.setBackground(Color.white);
		panel2.setPreferredSize(new Dimension(200, 120));
		frame.add(panel2, BorderLayout.CENTER);
		panel2.setLayout(null);

		label1 = new JLabel("User Name:");
		label1.setSize(180, 50);
		label1.setBounds(200, 7, 150, 150);
		panel2.add(label1);
		label1.setFont(new Font("Verdana", Font.BOLD, 20));

		label2 = new JLabel("Password:");
		label2.setSize(180, 50);
		label2.setBounds(215, 50, 150, 150);
		panel2.add(label2);
		label2.setFont(new Font("Verdana", Font.BOLD, 20));

		txt = new JTextField();
		txt.setBounds(350, 70, 150, 30);
		panel2.add(txt);

		pass = new JPasswordField();
		pass.setBounds(350, 110, 150, 30);
		panel2.add(pass);

		btn = new JButton("Login");
		btn.setBounds(200, 150, 170, 40);
		btn.setFont(new Font("Verdana", Font.BOLD, 25));
		btn.setBackground(Color.white);
		panel2.add(btn);
		

		btn1 = new JButton("Register Now");
		btn1.setBounds(375, 150, 230, 40);
		btn1.setFont(new Font("Verdana", Font.BOLD, 25));
		btn1.setBackground(Color.white);
		panel2.add(btn1);
		//Action
		btn1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				if (ae.getSource() == btn1) {
					new Reg();
			}
			}
			});
		
		
		
		
		label = new JLabel("Welcome to HOTEL LUTON");
		label.setFont(new Font("Verdana", Font.BOLD, 25));
		label.setForeground(Color.white);
		panel.add(label);

		
		
		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == btn) {
			new Dash();
		}

	}

	public static void main(String[] args) {
		new LoginP();

	}
}
