package ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class log {
	JFrame frame;
	JLabel label, label1;
	JPanel panel, panel1, panel2;
	JTextField txt;

	public log() {
		frame = new JFrame("LOTON");
		frame.setSize(800, 650);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setLayout(null);

		panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(0, 0, 800, 710);

		panel1 = new JPanel();
		panel1.setBounds(250, 100, 280, 400);

		panel1.setBackground(Color.white);
		panel1.setBackground(new Color(2,136,111));
		frame.add(panel1);

		panel1.setLayout(new BorderLayout());

		panel2 = new JPanel();

		panel2.setPreferredSize(new Dimension(150, 50));
		panel2.setBackground(new Color(239,255,254));
		panel1.add(panel2, BorderLayout.NORTH);
		

		label1 = new JLabel("login");
		label1.setFont(new Font("Verdana", Font.BOLD, 22));
		panel2.add(label1);

		label = new JLabel();
		Image img = new ImageIcon(this.getClass().getResource("tabel.jpg")).getImage();
		label.setBounds(0, 0, 800, 650);
		label.setIcon(new ImageIcon(img));
		frame.add(label);

		frame.setVisible(true);

	}

	public static void main(String[] args) {

		new log();
	}

}
