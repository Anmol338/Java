package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class Reg implements ActionListener{

	JButton btn;
 JPanel panel ,panel1;
 JFrame frame;
 JLabel label , label1,label2,label3,label4,label5,label6,label7,label8,label9;
 JTextField txt ,txt1,txt2,txt3,txt4,txt5,txt6;
	public Reg() {
		 frame = new JFrame("LOTON");
			frame.setSize(850, 650);
			frame.setResizable(false);
			frame.setLocationRelativeTo(null);
			frame.setLayout(null);
			
			panel = new JPanel();
			panel.setBounds(180,50,480,480);
			panel.setBackground(new Color(247,243,227));
			panel.setLayout(null);
			frame.add(panel);
			
			
			
			label1 = new JLabel("Registration");
			label1.setBounds(160,5,200,50);
			label1.setFont(new Font("Verdana",Font.BOLD,27));
			
			panel.add(label1);
			
			label2 = new JLabel("Name: ");
			label2.setBounds(10,55,80,50);
			label2.setFont(new Font("Verdana",Font.PLAIN,19));
			panel.add(label2);
			
			txt = new JTextField();
			txt.setBounds(80,67,120,30);
			panel.add(txt);
			txt.addActionListener(this);
			
			
			
			label3 = new JLabel("Last Name: ");
			label3.setBounds(220,55,160,50);
			label3.setFont(new Font("Verdana",Font.PLAIN,19));
			panel.add(label3);
			
			txt1 = new JTextField();
			txt1.setBounds(335,67,120,30);
			panel.add(txt1);
			
//
			label4 = new JLabel("Address: ");
			label4.setBounds(10,100,100,60);
			label4.setFont(new Font("Verdana",Font.PLAIN,19));
			panel.add(label4);
			
			txt2 = new JTextField();
			txt2.setBounds(100,117,170,30);
			panel.add(txt2);
			
			
//			
			label5 = new JLabel("Email: ");
			label5.setBounds(10,150,160,50);
			label5.setFont(new Font("Verdana",Font.PLAIN,19));
			panel.add(label5);
			
			txt3 = new JTextField();
			txt3.setBounds(100,163,170,30);
			panel.add(txt3);
//
			
			label6 = new JLabel("Phone No:");
			label6.setBounds(10,200,160,50);
			label6.setFont(new Font("Verdana",Font.PLAIN,19));
			panel.add(label6);
			
			txt4 = new JTextField();
			txt4.setBounds(109,213,170,30);
			panel.add(txt4);
			//		
			
			label7 = new JLabel("Gender :");
			label7.setBounds(10,245,160,50);
			label7.setFont(new Font("Verdana",Font.PLAIN,19));
			panel.add(label7);
			
			JRadioButton r1=new JRadioButton("A) Male");  
			r1.setBounds(109,263,80,20);
			panel.add(r1);
			
			 r1=new JRadioButton("B) Female");  
			r1.setBounds(200,263,100,20);
			panel.add(r1);
			
			 r1=new JRadioButton("C) Other");  
			r1.setBounds(309,263,100,20);
			panel.add(r1);
	//
		
			label8 = new JLabel("Password :");
			label8.setBounds(10,290,160,50);
			label8.setFont(new Font("Verdana",Font.PLAIN,19));
			panel.add(label8);
			
			JPasswordField p =new JPasswordField();
			p.setBounds(120,303,170,30);
			panel.add(p);
			
			//
			
			label9 = new JLabel("Confirm Pass :");
			label9.setBounds(10,330,160,50);
			label9.setFont(new Font("Verdana",Font.PLAIN,19));
			panel.add(label9);
			
			JPasswordField p1 =new JPasswordField();
			p1.setBounds(159,343,170,30);
			panel.add(p1);
			//
			
			JComboBox box = new JComboBox();
			
			
			
			
			
			label = new JLabel();
			Image img = new ImageIcon(this.getClass().getResource("bed.jpg")).getImage();
			label.setBounds(0,0,850,634);
			label.setIcon(new ImageIcon(img));
			frame.add(label);
			
			
			
			
		
	   btn = new JButton("submit");
		btn.setBounds(150,430, 170, 40);
		btn.setBackground(new Color(190, 41, 236));
		btn.setFont(new Font("Verdana", Font.BOLD, 28));
		btn.setOpaque(false);
		panel.add(btn);
		
	
	frame.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == txt) {
			String fName = txt.getText();
			
	}
	}
	
	public static void main(String[] args) {
		new Reg();

	}
}
