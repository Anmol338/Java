package ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class Dash implements ActionListener{
	JFrame frame;
	JPanel panel,panel2,panel3,panel4,panel1;
	JLabel label, label1;
	JComboBox combo;
	JTabbedPane tab;
	JButton btn ,btn1;

	public Dash() {

		frame = new JFrame("Dashboard");
		frame.setLayout(new BorderLayout());
		frame.setExtendedState(frame.MAXIMIZED_BOTH);
		frame.setSize(250, 250);
		
		frame.setResizable(false);

		panel = new JPanel();
		panel.setBackground(new Color(190, 41, 236));
		panel.setPreferredSize(new Dimension(150, 100));
		panel.setLayout(null);
		frame.add(panel, BorderLayout.NORTH);
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("LOGO2.png")));

		label = new JLabel();
		Image img = new ImageIcon(this.getClass().getResource("LOGO2.png")).getImage();
		label.setBounds(10, 10, 130, 50);

		label.setIcon(new ImageIcon(img));
		panel.add(label);

		label1 = new JLabel(" HOTEL LUTON");
		label1.setBounds(650, 10, 230, 60);
		label1.setFont(new Font("Verdana", Font.BOLD, 28));
		panel.add(label1);
//logout
		btn = new JButton("logOut");
		btn.setBounds(1400, 15, 130, 40);
		btn.setBackground(new Color(190, 41, 236));
		btn.setBorder(BorderFactory.createLineBorder(new Color(190, 41, 236)));
		btn.setFont(new Font("Verdana", Font.BOLD, 28));
		btn.setOpaque(false);
		btn.addActionListener(new ActionListener() {
@Override 
		public void actionPerformed(ActionEvent ae) {
	if(ae.getSource()==btn) {
		frame.dispose();
		log b1=new log();
		
	}
	
}
		
});
	
		//
		panel.add(btn);

		// Tab ko codess
		tab = new JTabbedPane();
		tab.setBounds(10, 10, 550, 550);
		frame.add(tab);

		panel1 = new JPanel();
		panel1.setBackground(Color.blue);
		tab.add("Home", panel1);

		
		
		panel2 = new JPanel();
		panel2.setBackground(Color.red);
		tab.add("Rooms", panel2);
		panel2.setLayout(null);
		
		btn1= new JButton("Standered");
		
		btn1.setBounds(15,15,200,100);
		panel2.add(btn1);
		
		
		panel3=new JPanel();
		tab.add("Food",panel3);
		
		
		panel4 = new JPanel();
		panel4.setBackground(Color.green);
		tab.add("About Us", panel4);


		frame.setVisible(true);
	}

	public static void main(String[] args) {
		new Dash();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
